import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})


export class ApiService {
  Baseurl="http://localhost:8080/mini_project_5_0/"


  constructor(private http:HttpClient) {}
  // user Resigtration
  postDetails(data: any) {
    return this.http.post(`${this.Baseurl}save`, data)
  }
  getDetails(data:any) {
       return this.http.get(`${this.Baseurl}getuser`,data)
  }

  //forgotpassword
  forgotpass(data:any){
    return this.http.put(`${this.Baseurl}updatepassword`,data)
  } 

  //otp verification
  postotp(to:any){
    return this.http.post(`${this.Baseurl}sendotp`,to) 
  }

  //Files
postfile(file:any){

  return this.http.post(`${this.Baseurl}filesave?userid=`+localStorage.getItem('id')+'&readfile=1&writefile=1&shareby='+localStorage.getItem('email'),file)
}
getAllFiles(userid:any){
  return this.http.post(`${this.Baseurl}getfiles`,userid)
}
getRecentFiles(userid:any){
  return this.http.post(`${this.Baseurl}recentfiles`,userid)
}
deleteFile(fileid:any){
  return this.http.delete(`${this.Baseurl}deletefile?fileid=`+fileid)
}

  //Files share
  sharefile(file:any,id:any,read1:any,write1:any){

    return this.http.post(`${this.Baseurl}filesave?userid=`+id+'&readfile='+read1+'&writefile='+write1+'&shareby='+localStorage.getItem('email'),file)
  }
  //get id by email
  getidbyemail(email:any){
    return this.http.get(`${this.Baseurl}getidbyemail?email=`+email)
  }
  sharewithme(obj:any)
  {
    return this.http.post(`${this.Baseurl}sharewithme`,obj)
  }
  gettext(filename:any)
  {
   
    return this.http.get(`${this.Baseurl}gettext?filename=`+filename,{responseType: 'text'})
  }
  settext(filename:any,txt:any){
    return this.http.get(`${this.Baseurl}settext?filename=`+filename+`&txt=`+txt);
  }

}
