import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { ApiService } from '../services/api.service';

@Component({
  selector: 'app-fileupload',
  templateUrl: './fileupload.component.html',
  styleUrls: ['./fileupload.component.scss']
})
export class FileuploadComponent implements OnInit {
  fileName = '';
  filetoupload:any
  userid:any
  data:any
  share: any = false;
   selectedFW = new FormControl();
   Email: string[] = [];
   btn:any
   read1:any
   write1:any
   data1:any
   id:any

  
  constructor(private service:ApiService) { 
     this.btn=false
    
  }

  form = new FormGroup({
    read:new FormControl(),
    write:new FormControl()
  })

  onSubmit(form:any){
    console.log("hello");
    
    
    if(form.value.read==true){
      this.read1=1
    }
    else{
      this.read1=0
    }
    if(form.value.write==true){
      this.write1=1
    }
    else{
      this.write1=0
    }
    console.log(this.read1);
    console.log(this.selectedFW.value);
    this.service.getidbyemail(this.selectedFW.value).subscribe(res=>{
     this.data1=res;
     console.log(this.data1[0].id);
     this.id=this.data1[0].id;
    })
    var fileData = new FormData();
    fileData.append('file',this.filetoupload)
    this.service.sharefile(fileData,this.id,this.read1,this.write1).subscribe(res=>{
      console.log(res);
      
    })
    
  }

  ngOnInit(): void {

  }
  sharewith(){
    this.share=true

  }
  onFilechange(event: any) {

    this.btn=true
    this.filetoupload= event.target.files[0]
    this.fileName = this.filetoupload.name;
    
    var fileData = new FormData();
    fileData.append('file',this.filetoupload)
    //  this.userid=10
    
this.service.postfile(fileData).subscribe(res=>{
  console.log(res);
})
this.service.getDetails(this.userid).subscribe(res=>{
  this.data=res;
  console.log(this.data.length);
  for(let i = 0; i < this.data.length; i++){  // loop through the object array
    this.Email.push(this.data[i].email);        // push each element to sys_id
  }
  
})

    } 
  }

