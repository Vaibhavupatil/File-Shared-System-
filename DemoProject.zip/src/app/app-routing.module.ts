import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DashboardComponent } from './dashboard/dashboard.component';
import { FileuploadComponent } from './fileupload/fileupload.component';
import { ForgotpasswordComponent } from './forgotpassword/forgotpassword.component';
import { LoginComponent } from './login/login.component';
import { NavigationComponent } from './navigation/navigation.component';
import { OtpverificationComponent } from './otpverification/otpverification.component';
import { RegisterComponent } from './register/register.component';
import { SharedWithMeFileComponent } from './shared-with-me-file/shared-with-me-file.component';


const routes: Routes = [
  // {
  //   path:'',
  //   component:NavigationComponent
  // },
  {
    path:'login',
    component:LoginComponent
  },
  {
    path:'register',
    component:RegisterComponent
  },
  {
    path:'otpverify',
    component:OtpverificationComponent
  },
  {
    path:'dashboard',
    component:DashboardComponent
  },
  {
    
    path:'forgotpassword',
    component:ForgotpasswordComponent
  },
  {
    
    path:'fileupload',
    component:FileuploadComponent
  },
  {
    
    path:'sharewithme',
    component:SharedWithMeFileComponent
  }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
